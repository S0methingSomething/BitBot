# SPDX-FileCopyrightText: 2024-present Your Name <your@email.com>
#
# SPDX-License-Identifier: MIT
"""
BitBot: A Reddit bot for managing release posts.
"""
