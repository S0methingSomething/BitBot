import argparse
import sys
import os
import re
from datetime import datetime, timezone, timedelta
from . import config, state, reddit, github


def _update_bot_state(post_id: str):
    """Resets bot_state.json and signals a change to the workflow."""
    cfg = config.get_config()
    st = state.get_state()
    st.update(
        {
            "activePostId": post_id,
            "lastCheckTimestamp": datetime.now(timezone.utc).isoformat(),
            "currentIntervalSeconds": cfg["timing"]["firstCheck"],
            "lastCommentCount": 0,
        }
    )
    state.save_state()
    print(f"State file updated. Now monitoring post: {post_id}")
    with open(os.environ.get("GITHUB_OUTPUT", "/dev/null"), "a") as f:
        print("state_changed=true", file=f)


def _post(args):
    """Handles posting a new release."""
    cfg = config.get_config()
    r = reddit.get_reddit_instance()

    print("Fetching existing posts to prepare for update...")
    existing_posts = reddit.get_bot_posts(r, cfg)

    new_submission = reddit.post_new_release(
        r, args.version, args.direct_download_url, cfg
    )

    if existing_posts:
        print(f"Found {len(existing_posts)} older post(s) to update.")
        latest_release_details = {
            "title": new_submission.title,
            "url": new_submission.shortlink,
            "version": args.version,
            "direct_download_url": args.direct_download_url,
        }
        reddit.update_older_posts(existing_posts, latest_release_details, cfg)

    print("Updating state file to monitor latest post.")
    _update_bot_state(new_submission.id)
    print("Post and update process complete.")


def _sync():
    """Handles syncing Reddit state with GitHub releases."""
    cfg = config.get_config()
    st = state.get_state()
    r = reddit.get_reddit_instance()

    latest_bot_release = github.get_latest_release(cfg)
    if not latest_bot_release:
        sys.exit(1)

    print(
        f"Latest available bot release on GitHub is v{latest_bot_release['version']}."
    )
    bot_posts_on_sub = reddit.get_bot_posts(r, cfg)

    if not bot_posts_on_sub:
        print(
            f"No posts found in r/{cfg['reddit']['subreddit']}. Posting latest available release."
        )
        new_submission = reddit.post_new_release(
            r, latest_bot_release["version"], latest_bot_release["url"], cfg
        )
        _update_bot_state(new_submission.id)
        return

    latest_reddit_post = bot_posts_on_sub[0]

    # A simple regex to parse version from title, assuming format 'vX.Y.Z'
    match = re.search(r"v(\d+\.\d+\.\d+)", latest_reddit_post.title)
    latest_reddit_version = match.group(1) if match else "0.0.0"

    print(f"Latest post on Reddit is v{latest_reddit_version}.")

    if latest_bot_release["version"] > latest_reddit_version:
        print(
            f"Reddit is out of sync (Reddit: v{latest_reddit_version}, GitHub: v{latest_bot_release['version']}). Posting update."
        )
        new_submission = reddit.post_new_release(
            r, latest_bot_release["version"], latest_bot_release["url"], cfg
        )

        latest_release_details = {
            "title": new_submission.title,
            "url": new_submission.shortlink,
            "version": latest_bot_release["version"],
            "direct_download_url": latest_bot_release["url"],
        }
        reddit.update_older_posts(bot_posts_on_sub, latest_release_details, cfg)
        _update_bot_state(new_submission.id)
        return

    print("Reddit's latest post is up-to-date. Performing routine sync.")

    older_posts = bot_posts_on_sub[1:]
    if older_posts:
        print(
            f"Checking {len(older_posts)} older post(s) to ensure they are marked as outdated."
        )
        latest_release_details = {
            "title": latest_reddit_post.title,
            "url": latest_reddit_post.shortlink,
            "version": latest_bot_release["version"],
            "direct_download_url": latest_bot_release["url"],
        }
        reddit.update_older_posts(older_posts, latest_release_details, cfg)
    else:
        print("No older posts found to sync.")

    if st.get("activePostId") != latest_reddit_post.id:
        print("State file is out of sync. Correcting it.")
        _update_bot_state(latest_reddit_post.id)
    else:
        print("State file is already in sync.")
        with open(os.environ.get("GITHUB_OUTPUT", "/dev/null"), "a") as f:
            print("state_changed=false", file=f)


def _check():
    """
    Checks for comments on the active Reddit post, analyzes feedback, and
    updates the post status with an adaptive timer.
    """
    cfg = config.get_config()
    st = state.get_state()
    state_was_meaningfully_updated = False

    if not st.get("activePostId"):
        print("No active post ID in state file. Exiting pulse.")
        sys.exit(0)

    now = datetime.now(timezone.utc)
    last_check = datetime.fromisoformat(st["lastCheckTimestamp"].replace("Z", "+00:00"))

    if now < (last_check + timedelta(seconds=st["currentIntervalSeconds"])):
        # Corrected line with fixed parenthesis placement.
        print(
            f"Not time yet. Next check in {int(((last_check + timedelta(seconds=st['currentIntervalSeconds'])) - now).total_seconds())}s."
        )
        with open(os.environ.get("GITHUB_OUTPUT", "/dev/null"), "a") as f:
            print("state_changed=false", file=f)
        sys.exit(0)

    print(f"Time for a real check on post: {st['activePostId']}")
    try:
        r = reddit.get_reddit_instance()
        submission = r.submission(id=st["activePostId"])
        submission.comments.replace_more(limit=0)
        comments = submission.comments.list()

        working_kw = re.compile("|".join(cfg["feedback"]["workingKeywords"]), re.I)
        not_working_kw = re.compile(
            "|".join(cfg["feedback"]["notWorkingKeywords"]), re.I
        )
        positive_score = sum(1 for c in comments if working_kw.search(c.body))
        negative_score = sum(1 for c in comments if not_working_kw.search(c.body))
        net_score = positive_score - negative_score
        print(
            f"Comment analysis: Positive={positive_score}, Negative={negative_score}, Net Score={net_score}"
        )

        threshold = cfg["feedback"]["minFeedbackCount"]
        if net_score <= -threshold:
            new_status_text = cfg["feedback"]["labels"]["broken"]
        elif net_score >= threshold:
            new_status_text = cfg["feedback"]["labels"]["working"]
        else:
            new_status_text = cfg["feedback"]["labels"]["unknown"]

        new_status_line = cfg["feedback"]["statusLineFormat"].replace(
            "{{status}}", new_status_text
        )

        status_regex = re.compile(cfg["feedback"]["statusLineRegex"], re.MULTILINE)
        if not status_regex.search(submission.selftext):
            print(
                "::warning::Could not find status line in post. It may have been edited or is an outdated post."
            )
        elif new_status_line not in submission.selftext:
            updated_body = status_regex.sub(new_status_line, submission.selftext)
            submission.edit(body=updated_body)
            print(f"Status updated to: {new_status_text}")
        else:
            print("Status is already correct.")

        if len(comments) > st["lastCommentCount"]:
            st["currentIntervalSeconds"] = cfg["timing"]["firstCheck"]
            state_was_meaningfully_updated = True
        else:
            if st["currentIntervalSeconds"] < cfg["timing"]["maxWait"]:
                st["currentIntervalSeconds"] = min(
                    cfg["timing"]["maxWait"],
                    st["currentIntervalSeconds"] + cfg["timing"]["increaseBy"],
                )
                state_was_meaningfully_updated = True

        if st["lastCommentCount"] != len(comments):
            st["lastCommentCount"] = len(comments)
            state_was_meaningfully_updated = True

    except Exception as e:
        print(f"::error::An exception occurred during check: {e}", file=sys.stderr)
    finally:
        st["lastCheckTimestamp"] = now.isoformat().replace("+00:00", "Z")
        if state_was_meaningfully_updated:
            print("Meaningful state change detected. Saving state file.")
            state.save_state()
        else:
            print("No meaningful state change detected. Skipping file write.")

        with open(os.environ.get("GITHUB_OUTPUT", "/dev/null"), "a") as f:
            print(
                f"state_changed={str(state_was_meaningfully_updated).lower()}", file=f
            )
        print(f"Pulse check complete. Next interval: {st['currentIntervalSeconds']}s")


def main():
    parser = argparse.ArgumentParser(
        description="BitBot: A Reddit bot for managing release posts."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    post_parser = subparsers.add_parser("post", help="Post a new release to Reddit.")
    post_parser.add_argument("--version", required=True)
    post_parser.add_argument("--direct-download-url", required=True)
    post_parser.set_defaults(func=_post)

    sync_parser = subparsers.add_parser(
        "sync", help="Sync Reddit history with GitHub releases."
    )
    sync_parser.set_defaults(func=_sync)

    check_parser = subparsers.add_parser(
        "check", help="Check for comments on the active post."
    )
    check_parser.set_defaults(func=_check)

    args = parser.parse_args()

    config.load_config()
    state.load_state()

    if hasattr(args, "func"):
        if args.command == "post":
            args.func(args)
        else:
            args.func()


if __name__ == "__main__":
    main()
