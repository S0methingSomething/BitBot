import subprocess
import sys


def process_file(input_file: str, output_file: str):
    """
    Calls the process_vars.js script to handle the file processing.
    """
    try:
        subprocess.run(
            ["node", "process_vars.js", input_file, output_file],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as e:
        print(
            f"::error::Failed to process file with process_vars.js: {e}",
            file=sys.stderr,
        )
        print(f"Stderr: {e.stderr}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print(
            "::error::`node` command not found. NodeJS is required to run the processor.",
            file=sys.stderr,
        )
        sys.exit(1)
