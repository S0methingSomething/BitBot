import toml
from typing import Any, Dict

_config: Dict[str, Any] = {}


def load_config(config_path: str = "config.toml") -> None:
    """Loads the main configuration file."""
    global _config
    with open(config_path, "r") as f:
        _config = toml.load(f)


def get_config() -> Dict[str, Any]:
    """Returns the loaded configuration."""
    return _config
