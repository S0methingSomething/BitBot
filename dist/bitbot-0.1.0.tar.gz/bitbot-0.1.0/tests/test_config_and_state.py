import toml
from pathlib import Path

from bitbot.config import load_config, get_config
from bitbot.state import load_state, get_state, save_state


def test_load_config(tmp_path: Path):
    config_content = {"test_key": "test_value"}
    config_file = tmp_path / "config.toml"
    with open(config_file, "w") as f:
        toml.dump(config_content, f)

    load_config(str(config_file))
    assert get_config() == config_content


def test_load_state(tmp_path: Path):
    state_content = {"processed_posts": ["post1", "post2"]}
    state_file = tmp_path / "state.toml"
    with open(state_file, "w") as f:
        toml.dump(state_content, f)

    load_state(str(state_file))
    assert get_state() == state_content


def test_save_state(tmp_path: Path):
    state_content = {"processed_posts": ["post1", "post2", "post3"]}
    state_file = tmp_path / "state.toml"

    # The new save_state function saves the global state, so we need to set it first
    load_state(str(state_file)) # To initialize the state
    get_state().update(state_content)
    save_state(str(state_file))

    with open(state_file, "r") as f:
        saved_state = toml.load(f)

    assert saved_state == state_content
