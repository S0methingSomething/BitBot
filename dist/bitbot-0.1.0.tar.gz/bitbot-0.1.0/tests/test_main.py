import pytest
from unittest.mock import MagicMock, patch
from bitbot.__main__ import main

@pytest.fixture
def mock_config_data():
    """Fixture for mock config data."""
    return {
        "feedback": {
            "workingKeywords": ["works"],
            "notWorkingKeywords": ["broken"],
            "minFeedbackCount": 1,
            "labels": {
                "working": "Working",
                "broken": "Broken",
                "unknown": "Unknown",
            },
            "statusLineFormat": "Status: {{status}}",
            "statusLineRegex": r"^Status:.*$",
        },
        "timing": {
            "firstCheck": 60,
            "maxWait": 120,
            "increaseBy": 10,
        },
    }

@pytest.fixture
def mock_state_data():
    """Fixture for mock state data."""
    return {
        "activePostId": "test_post_id",
        "lastCheckTimestamp": "2024-01-01T00:00:00Z",
        "currentIntervalSeconds": 60,
        "lastCommentCount": 0,
    }

@patch('bitbot.config.get_config')
@patch('bitbot.state.get_state')
@patch('bitbot.state.save_state')
@patch('bitbot.reddit.get_reddit_instance')
def test_check_command(mock_get_reddit, mock_save_state, mock_get_state, mock_get_config, mock_config_data, mock_state_data, capsys):
    """
    Tests the check command logic.
    """
    mock_get_config.return_value = mock_config_data
    mock_get_state.return_value = mock_state_data

    mock_reddit = MagicMock()
    mock_submission = MagicMock()
    mock_submission.selftext = "Status: Unknown"
    mock_submission.comments.list.return_value = []
    mock_reddit.submission.return_value = mock_submission
    mock_get_reddit.return_value = mock_reddit

    with patch('sys.argv', ['bitbot', 'check']):
        with patch('bitbot.config.load_config'), patch('bitbot.state.load_state'):
             main()

    # Verify that the state was saved
    mock_save_state.assert_called_once()
    
    # Capture output and check if it contains expected messages
    captured = capsys.readouterr()
    assert "Time for a real check on post" in captured.out
    assert "Status is already correct" in captured.out
